﻿using bb89.convert;
using bb89.trans;
using bb89.wallet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.trans_proc
{
    public class TransactionProcessor : ITransactionProcessor
    {
        private readonly IWallet wallet;
        private readonly ICurrencyConverter converter;
        private readonly ITransactionHistory history;

        public TransactionProcessor(IWallet wallet, ICurrencyConverter converter, ITransactionHistory history)
        {
            this.wallet = wallet;
            this.converter = converter;
            this.history = history;
        }

        public async Task RunAsync()
        {
            while (true)
            {
                Console.WriteLine("Пополнить [п], Конвертировать [к], История [и], Выйти [в]");
                var choice = Console.ReadLine().ToLower();

                if (choice == "в") break; // Выход
                else if (choice == "и") DisplayTransactionHistory(); // Отображение истории
                else if (choice == "п")
                {
                    Console.Write("Введите валюту для пополнения: ");
                    var currency = Console.ReadLine().ToUpper();
                    Console.Write("Введите сумму: ");
                    if (decimal.TryParse(Console.ReadLine(), out var amount) && amount > 0)
                    {
                        await HandleDepositAsync(currency, amount); // Обработка пополнения с передачей параметров
                    }
                    else
                    {
                        Console.WriteLine("Некорректная сумма.");
                    }
                }
                else if (choice == "к")
                {
                    Console.Write("Введите исходную валюту: ");
                    var fromCurrency = Console.ReadLine().ToUpper();
                    Console.Write("Введите целевую валюту: ");
                    var toCurrency = Console.ReadLine().ToUpper();
                    Console.Write("Введите сумму: ");
                    if (decimal.TryParse(Console.ReadLine(), out var amount) && amount > 0)
                    {
                        await HandleConversionAsync(fromCurrency, toCurrency, amount); // Обработка конвертации с передачей параметров
                    }
                    else
                    {
                        Console.WriteLine("Некорректная сумма.");
                    }
                }
                else
                {
                    Console.WriteLine("Некорректный выбор.");
                }
            }

            await history.SaveHistoryAsync(); // Сохранение истории
        }

        public async Task HandleDepositAsync(string currency, decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Сумма пополнения должна быть положительной");
            }

            wallet.Deposit(currency, amount);
            history.AddTransaction($"Пополнение {amount} {currency}");
            Console.WriteLine($"Успешно пополнено: {amount} {currency}");
        }




        public async Task HandleConversionAsync(string fromCurrency, string toCurrency, decimal amount)
        {
            if (!wallet.Withdraw(fromCurrency, amount))
            {
                Console.WriteLine("Недостаточно средств.");
                return;
            }

            var convertedAmount = await converter.ConvertAsync(amount, fromCurrency, toCurrency);
            wallet.Deposit(toCurrency, convertedAmount);
            history.AddTransaction($"Конвертация {amount} {fromCurrency} в {convertedAmount} {toCurrency}");
            Console.WriteLine($"Конвертировано: {amount} {fromCurrency} в {convertedAmount} {toCurrency}");
        }



        public void DisplayTransactionHistory()
        {
            foreach (var record in history.GetTransactions())
            {
                Console.WriteLine(record);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.trans_proc
{
    public interface ITransactionProcessor
    {
        Task RunAsync();
        Task HandleDepositAsync(string currency, decimal amount);
        Task HandleConversionAsync(string fromCurrency, string toCurrency, decimal amount);
        void DisplayTransactionHistory();
    }

}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using bb89.db;

namespace bb89.convert
{
    public class CurrencyConverter
    {
        private readonly IDatabase _database;

        public CurrencyConverter(IDatabase database)
        {
            _database = database;
        }

        public async Task<decimal> ConvertAsync(decimal amount, string fromCurrency, string toCurrency)
        {
            // Получаем курсы обмена
            var exchangeRates = await _database.GetExchangeRatesAsync();

            // Проверяем наличие валют в курсе
            if (!exchangeRates.ContainsKey(fromCurrency) || !exchangeRates.ContainsKey(toCurrency))
            {
                throw new InvalidOperationException("Курс валюты не найден.");
            }

            // Получаем курсы
            var fromRate = exchangeRates[fromCurrency];
            var toRate = exchangeRates[toCurrency];

            // Выполняем конвертацию
            return amount * (toRate / fromRate);
        }
    }


}

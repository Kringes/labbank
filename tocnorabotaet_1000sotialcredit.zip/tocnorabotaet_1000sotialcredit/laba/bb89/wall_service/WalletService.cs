﻿using bb89.db;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using bb89.wallet;

namespace bb89.services
{
    public class WalletService
    {
        private readonly IDatabase _database;

        public WalletService(IDatabase database)
        {
            _database = database;
        }

        public async Task<List<WalletModel>> GetWalletsForUserAsync(int userId)
        {
            return await _database.GetWalletsForUserAsync(userId);
        }

        public async Task AddFundsAsync(int userId, string currencyCode, decimal amount)
        {
            var wallets = await _database.GetWalletsForUserAsync(userId);
            var wallet = wallets.FirstOrDefault(w => w.CurrencyCode == currencyCode);

            if (wallet == null)
            {
                throw new KeyNotFoundException($"Wallet with currency {currencyCode} not found for user {userId}");
            }

            var newBalance = wallet.Balance + amount;
            await _database.UpdateWalletBalanceAsync(wallet.WalletId, newBalance);
        }

        public async Task CreateWalletsForUserAsync(int userId)
        {
            await _database.CreateWalletsForUserAsync(userId);
        }
    }
}

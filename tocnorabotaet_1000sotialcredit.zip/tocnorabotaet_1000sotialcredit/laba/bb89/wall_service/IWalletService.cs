﻿using System.Collections.Generic;
using System.Threading.Tasks;
using bb89.db;
using bb89.wallet;

namespace bb89.wall_service
{
    public interface IWalletService
    {
        Task<IEnumerable<Wallet>> GetWalletsForUserAsync(int userId);
        Task DepositAsync(int userId, string currency, decimal amount);
        Task<Wallet> GetWalletByCurrencyAsync(int userId, string currency);
    }
}

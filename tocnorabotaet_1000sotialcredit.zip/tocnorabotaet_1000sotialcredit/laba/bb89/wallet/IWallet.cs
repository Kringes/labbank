﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.wallet
{
    public interface IWallet
    {
        void Deposit(string currency, decimal amount);
        bool Withdraw(string currency, decimal amount);
        decimal GetBalance(string currency);
        Dictionary<string, decimal> GetBalances();
    }
}
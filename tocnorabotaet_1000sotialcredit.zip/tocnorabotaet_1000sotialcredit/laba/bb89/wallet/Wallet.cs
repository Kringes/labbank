﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.wallet
{
    public class Wallet : IWallet
    {
        private readonly Dictionary<string, decimal> balances;

        public Wallet(IEnumerable<string> currencies)
        {
            balances = new Dictionary<string, decimal>();
            foreach (var currency in currencies)
                balances[currency] = 0;
        }

        public void Deposit(string currency, decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Сумма пополнения должна быть положительной");
            }
            balances[currency] += amount;
        }

        public bool Withdraw(string currency, decimal amount)
        {
            if (!balances.ContainsKey(currency))
                throw new ArgumentException("Unknown currency.");

            if (balances[currency] < amount)
                throw new InvalidOperationException("Insufficient balance.");

            balances[currency] -= amount;
            return true;
        }

        public decimal GetBalance(string currency)
        {
            return balances.ContainsKey(currency) ? balances[currency] : 0;
        }

        public Dictionary<string, decimal> GetBalances()
        {
            return new Dictionary<string, decimal>(balances);
        }
    }
}
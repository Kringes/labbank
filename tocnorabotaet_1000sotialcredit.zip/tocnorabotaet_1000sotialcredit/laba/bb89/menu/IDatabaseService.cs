﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.menu
{
    public interface IDatabaseService
    {
        long CreateUser(string username, string password);
        long LoginUser(string username, string password);
        IEnumerable<(string Currency, decimal Balance)> GetWallets(long userId);
        void AddFunds(long userId, string currency, decimal amount);
        IEnumerable<(decimal Amount, string Currency, string Type, string Date)> GetTransactionHistory(long userId);
        decimal ConvertCurrency(long userId, string fromCurrency, string toCurrency, decimal amount);
    }

}

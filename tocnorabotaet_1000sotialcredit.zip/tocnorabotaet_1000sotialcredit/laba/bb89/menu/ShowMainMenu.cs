﻿using System;
using System.Data.SQLite;

namespace bb89.menu
{
    public class ShowMainMenu
    {
        private readonly string _connectionString;

        public ShowMainMenu(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void Run()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. Создать пользователя");
                Console.WriteLine("2. Войти в систему");
                Console.WriteLine("3. Выход");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        CreateUser();  // В этом случае без параметров
                        break;
                    case "2":
                        LoginUser();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Неверный ввод. Попробуйте снова.");
                        break;
                }
            }
        }

        public void CreateUser()
        {
            Console.Write("Введите имя пользователя: ");
            string username = Console.ReadLine();

            Console.Write("Введите пароль: ");
            string password = Console.ReadLine();

            CreateUser(username, password);  // Передаем параметры в основной метод
        }

        public void CreateUser(string username, string password)
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Создание пользователя
                string insertUserQuery = "INSERT INTO users (username, password) VALUES (@username, @password)";
                using (var command = new SQLiteCommand(insertUserQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);
                    command.ExecuteNonQuery();
                }

                // Получение ID только что созданного пользователя
                long userId;
                string getUserIdQuery = "SELECT last_insert_rowid()";
                using (var command = new SQLiteCommand(getUserIdQuery, connection))
                {
                    userId = (long)command.ExecuteScalar();
                }

                // Создание 4 кошельков для пользователя
                string[] currencies = { "RUB", "EUR", "TRL", "USD" };
                string insertWalletQuery = "INSERT INTO wallets (user_id, currency_code, balance) VALUES (@user_id, @currency_code, 0)";

                foreach (var currency in currencies)
                {
                    using (var command = new SQLiteCommand(insertWalletQuery, connection))
                    {
                        command.Parameters.AddWithValue("@user_id", userId);
                        command.Parameters.AddWithValue("@currency_code", currency);
                        command.ExecuteNonQuery();
                    }
                }

                Console.WriteLine("Пользователь успешно создан!");
            }
        }

        public void LoginUser()
        {
            Console.Write("Введите имя пользователя: ");
            string username = Console.ReadLine();

            Console.Write("Введите пароль: ");
            string password = Console.ReadLine();

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Проверка пользователя
                string loginQuery = "SELECT user_id FROM users WHERE username = @username AND password = @password";
                using (var command = new SQLiteCommand(loginQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);

                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        long userId = (long)result;
                        Console.WriteLine("Вход выполнен успешно!");
                        ShowUserMenu(userId);
                    }
                    else
                    {
                        Console.WriteLine("Неверное имя пользователя или пароль.");
                    }
                }
            }
        }

        private void ShowUserMenu(long userId)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. Кошелёк");
                Console.WriteLine("2. История транзакций");
                Console.WriteLine("3. Конвертировать валюту");
                Console.WriteLine("4. Выход");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ShowWallet(userId);
                        break;
                    case "2":
                        ShowTransactionHistory(userId);
                        break;
                    case "3":
                        ConvertCurrency(userId);
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Неверный ввод. Попробуйте снова.");
                        break;
                }
            }
        }

        private void ShowWallet(long userId)
        {
            while (true)
            {
                Console.Clear();
                using (var connection = new SQLiteConnection(_connectionString))
                {
                    connection.Open();

                    string query = "SELECT wallet_id, currency_code, balance FROM wallets WHERE user_id = @user_id";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@user_id", userId);

                        using (var reader = command.ExecuteReader())
                        {
                            Console.WriteLine("Ваши кошельки:");
                            while (reader.Read())
                            {
                                string currency = reader.GetString(1);
                                decimal balance = reader.GetDecimal(2);
                                Console.WriteLine($"{currency}: {balance}");
                            }
                        }
                    }

                    // Предложение пополнить кошелек
                    Console.WriteLine("\nХотите пополнить кошелек? (y/n)");
                    string replenishChoice = Console.ReadLine();
                    if (replenishChoice.ToLower() == "y")
                    {
                        Console.Write("Введите валюту для пополнения (RUB, EUR, TRL, USD): ");
                        string currency = Console.ReadLine().ToUpper();

                        Console.Write("Введите сумму для пополнения: ");
                        decimal amount = decimal.Parse(Console.ReadLine());

                        string updateWalletQuery = "UPDATE wallets SET balance = balance + @amount WHERE user_id = @user_id AND currency_code = @currency";
                        using (var command = new SQLiteCommand(updateWalletQuery, connection))
                        {
                            command.Parameters.AddWithValue("@amount", amount);
                            command.Parameters.AddWithValue("@user_id", userId);
                            command.Parameters.AddWithValue("@currency", currency);
                            int rows = command.ExecuteNonQuery();
                            if (rows > 0)
                            {
                                Console.WriteLine("Кошелек успешно пополнен!");
                                // Добавление записи о пополнении в историю транзакций
                                string insertTransactionQuery = @"
                                INSERT INTO transactions (wallet_id, amount, currency_code, transaction_type, created_at)
                                VALUES (
                                    (SELECT wallet_id FROM wallets WHERE user_id = @user_id AND currency_code = @currency),
                                    @amount, @currency, 'credit', datetime('now')
                                )";
                                using (var command2 = new SQLiteCommand(insertTransactionQuery, connection))
                                {
                                    command2.Parameters.AddWithValue("@user_id", userId);
                                    command2.Parameters.AddWithValue("@amount", amount);
                                    command2.Parameters.AddWithValue("@currency", currency);
                                    //command2.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                Console.WriteLine("Ошибка при пополнении кошелька.");
                            }
                        }
                    }

                    // Возвращаемся в меню
                    Console.WriteLine("\nНажмите любую клавишу для возврата в меню...");
                    Console.ReadKey();
                    return;
                }
            }
        }

        private void ShowTransactionHistory(long userId)
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                string query = @"
                SELECT t.transaction_id, t.amount, t.currency_code, t.transaction_type, t.created_at
                FROM transactions t
                JOIN wallets w ON t.wallet_id = w.wallet_id
                WHERE w.user_id = @user_id";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@user_id", userId);

                    using (var reader = command.ExecuteReader())
                    {
                        Console.WriteLine("История транзакций:");
                        while (reader.Read())
                        {
                            int transactionId = reader.GetInt32(0);
                            decimal amount = reader.GetDecimal(1);
                            string currencyCode = reader.GetString(2);
                            string transactionType = reader.GetString(3);
                            string createdAt = reader.GetString(4);

                            Console.WriteLine($"ID: {transactionId}, {transactionType} {amount} {currencyCode} на {createdAt}");
                        }
                    }
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для возврата в меню...");
            Console.ReadKey();
        }

        private void ConvertCurrency(long userId)
        {
            Console.Write("Введите исходную валюту: ");
            string fromCurrency = Console.ReadLine();

            Console.Write("Введите валюту назначения: ");
            string toCurrency = Console.ReadLine();

            Console.Write("Введите сумму: ");
            decimal amount = decimal.Parse(Console.ReadLine());

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Получение курса валют
                string rateQuery = "SELECT rate FROM currency_rates WHERE currency_from = @from AND currency_to = @to";
                decimal rate;

                using (var command = new SQLiteCommand(rateQuery, connection))
                {
                    command.Parameters.AddWithValue("@from", fromCurrency);
                    command.Parameters.AddWithValue("@to", toCurrency);
                    object result = command.ExecuteScalar();

                    if (result == null || result == DBNull.Value)
                    {
                        Console.WriteLine("Курс валют не найден.");
                        return;
                    }

                    rate = Convert.ToDecimal(result);
                }

                decimal convertedAmount = amount * rate;

                // Обновление баланса
                string updateWalletQuery = "UPDATE wallets SET balance = balance - @amount WHERE user_id = @user_id AND currency_code = @from";
                using (var command = new SQLiteCommand(updateWalletQuery, connection))
                {
                    command.Parameters.AddWithValue("@amount", amount);
                    command.Parameters.AddWithValue("@user_id", userId);
                    command.Parameters.AddWithValue("@from", fromCurrency);
                    command.ExecuteNonQuery();
                }

                string addWalletQuery = "UPDATE wallets SET balance = balance + @amount WHERE user_id = @user_id AND currency_code = @to";
                using (var command = new SQLiteCommand(addWalletQuery, connection))
                {
                    command.Parameters.AddWithValue("@amount", convertedAmount);
                    command.Parameters.AddWithValue("@user_id", userId);
                    command.Parameters.AddWithValue("@to", toCurrency);
                    command.ExecuteNonQuery();
                }

                // Добавление записи в историю транзакций
                string insertTransactionQuery = @"
    INSERT INTO transactions (wallet_id, amount, currency_code, transaction_type, created_at)
    VALUES (
        (SELECT wallet_id FROM wallets WHERE user_id = @user_id AND currency_code = @from),
        @amount, @from, 'Debit', datetime('now')
    )";

                using (var command = new SQLiteCommand(insertTransactionQuery, connection))
                {
                    command.Parameters.AddWithValue("@user_id", userId);
                    command.Parameters.AddWithValue("@amount", amount);
                    command.Parameters.AddWithValue("@from", fromCurrency);
                    command.ExecuteNonQuery();
                }

                // Добавление транзакции для зачисления на кошелек другой валюты
                string insertTransactionQueryCredit = @"
    INSERT INTO transactions (wallet_id, amount, currency_code, transaction_type, created_at)
    VALUES (
        (SELECT wallet_id FROM wallets WHERE user_id = @user_id AND currency_code = @to),
        @convertedAmount, @to, 'Credit', datetime('now')
    )";

                using (var command = new SQLiteCommand(insertTransactionQueryCredit, connection))
                {
                    command.Parameters.AddWithValue("@user_id", userId);
                    command.Parameters.AddWithValue("@convertedAmount", convertedAmount);
                    command.Parameters.AddWithValue("@to", toCurrency);
                    command.ExecuteNonQuery();
                }


                Console.WriteLine($"Успешная конвертация {amount} {fromCurrency} в {convertedAmount} {toCurrency}.");
            }
        }
    }
}



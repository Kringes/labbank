﻿using System;
using System.Threading.Tasks;
using bb89.wall_service;
using bb89.db;
using bb89.menu;
using bb89.services;
using bb89.wallet;

namespace bb89
{
    public class Program
    {
        public static async Task Main()
        {
            string connectionString = "Data Source=C:\\Users\\user\\Desktop\\base\\bb.db";
            var database = new Database(connectionString);
            var walletService = new WalletService(database);
            var menuManager = new ShowMainMenu(connectionString);
            menuManager.Run();


        }
    }
}

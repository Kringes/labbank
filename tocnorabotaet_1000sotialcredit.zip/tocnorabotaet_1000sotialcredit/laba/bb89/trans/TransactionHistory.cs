﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.trans
{
    public class TransactionHistory : ITransactionHistory
    {
        private readonly string filePath;
        private List<string> transactions;

        public TransactionHistory(string filePath)
        {
            this.filePath = filePath;
            transactions = new List<string>();
        }

        public async Task InitializeAsync()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл с историей транзакций не найден. Будет создан новый.");
                await File.WriteAllTextAsync(filePath, JsonConvert.SerializeObject(new List<string>()));
            }

            transactions.AddRange(await LoadHistoryAsync());
        }


        public void AddTransaction(string description)
        {
            transactions.Add(description);
        }

        public IReadOnlyList<string> GetTransactions()
        {
            return transactions.AsReadOnly();
        }

        public void DisplayHistory()
        {
            foreach (var record in transactions)
            {
                Console.WriteLine(record);
            }
        }

        public async Task SaveHistoryAsync()
        {
            var json = JsonConvert.SerializeObject(transactions);
            await File.WriteAllTextAsync(filePath, json);
        }


        private async Task<List<string>> LoadHistoryAsync()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл с историей транзакций не найден. Будет создан новый.");
                return new List<string>();
            }

            var json = await File.ReadAllTextAsync(filePath);
            return JsonConvert.DeserializeObject<List<string>>(json) ?? new List<string>();
        }
    }
}

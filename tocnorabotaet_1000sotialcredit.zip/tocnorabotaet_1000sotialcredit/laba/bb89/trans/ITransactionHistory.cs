﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89.trans
{
    public interface ITransactionHistory
    {
        void AddTransaction(string description);
        IReadOnlyList<string> GetTransactions();
        void DisplayHistory();
        Task SaveHistoryAsync();
    }
}

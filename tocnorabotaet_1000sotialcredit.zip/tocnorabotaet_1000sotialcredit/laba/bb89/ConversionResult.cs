﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bb89
{
    public class ConversionResult
    {
        public bool IsSuccess { get; }
        public decimal ConvertedAmount { get; }
        public string? ErrorMessage { get; }

        public ConversionResult(bool isSuccess, decimal convertedAmount, string? errorMessage)
        {
            IsSuccess = isSuccess;
            ConvertedAmount = convertedAmount;
            ErrorMessage = errorMessage;
        }
    }
}
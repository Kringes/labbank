﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Threading.Tasks;
using Dapper;

namespace bb89.db
{
    public class Database : IDatabase
    {
        private readonly string _connectionString;

        public Database(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Получение user_id по логину и паролю
        public async Task<int> GetUserIdAsync(string username, string password)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "SELECT user_id FROM users WHERE username = @Username AND password = @Password";
            var userId = await connection.QueryFirstOrDefaultAsync<int?>(sql, new { Username = username, Password = password });

            return userId ?? 0; // Если не найден, возвращаем 0
        }

        // Получение всех кошельков пользователя
        public async Task<List<WalletModel>> GetWalletsForUserAsync(int userId)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "SELECT wallet_id AS WalletId, user_id AS UserId, currency_code AS CurrencyCode, balance AS Balance " +
                      "FROM wallets WHERE user_id = @UserId";

            var wallets = await connection.QueryAsync<WalletModel>(sql, new { UserId = userId });
            return wallets.ToList();
        }

        // Обновление баланса кошелька
        public async Task UpdateWalletBalanceAsync(int walletId, decimal newBalance)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "UPDATE wallets SET balance = @NewBalance WHERE wallet_id = @WalletId";
            await connection.ExecuteAsync(sql, new { NewBalance = newBalance, WalletId = walletId });
        }

        // Создание кошелька для пользователя
        public async Task<int> CreateWalletAsync(int userId, string currency, decimal initialBalance)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "INSERT INTO wallets (user_id, currency_code, balance) VALUES (@UserId, @Currency, @Balance); SELECT last_insert_rowid();";
            var walletId = await connection.ExecuteScalarAsync<int>(sql, new { UserId = userId, Currency = currency, Balance = initialBalance });

            return walletId;
        }

        // Создание пользователя
        public async Task CreateUserAsync(string username, string password)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "INSERT INTO users (username, password) VALUES (@Username, @Password)";
            await connection.ExecuteAsync(sql, new { Username = username, Password = password });
        }

        // Получение всех транзакций пользователя
        public async Task<List<TransactionModel>> GetTransactionsForUserAsync(int userId)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "SELECT t.transaction_id AS TransactionId, t.wallet_id AS WalletId, t.amount AS Amount, " +
                      "t.currency_code AS CurrencyCode, t.transaction_type AS TransactionType, t.created_at AS CreatedAt " +
                      "FROM transactions t " +
                      "INNER JOIN wallets w ON t.wallet_id = w.wallet_id " +
                      "WHERE w.user_id = @UserId";

            var transactions = await connection.QueryAsync<TransactionModel>(sql, new { UserId = userId });
            return transactions.ToList();
        }


        public async Task<Dictionary<string, decimal>> GetExchangeRatesAsync(int userId, int page = 1, int pageSize = 16)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var offset = (page - 1) * pageSize;

            var sql = @"
            SELECT currency_code, rate 
            FROM exchange_rates
            WHERE user_id = @UserId
            LIMIT @PageSize OFFSET @Offset";

            var rates = new Dictionary<string, decimal>();

            using var command = new SQLiteCommand(sql, connection);
            command.Parameters.AddWithValue("@UserId", userId);
            command.Parameters.AddWithValue("@PageSize", pageSize);
            command.Parameters.AddWithValue("@Offset", offset);

            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                var currencyCode = reader.GetString(0);
                var rate = reader.GetDecimal(1);

                rates[currencyCode] = rate;
            }

            return rates;
        }


        // Получение курса обмена между двумя валютами
        public async Task<decimal> GetExchangeRateAsync(string fromCurrency, string toCurrency)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "SELECT rate FROM currency_rates WHERE currency_from = @FromCurrency AND currency_to = @ToCurrency";
            var rate = await connection.QueryFirstOrDefaultAsync<decimal?>(sql, new { FromCurrency = fromCurrency, ToCurrency = toCurrency });

            if (rate == null)
                throw new Exception($"Exchange rate not found for {fromCurrency} to {toCurrency}");

            return rate.Value;
        }

        // Создание кошельков для пользователя по умолчанию (например, RUB, USD, EUR)
        public async Task CreateWalletsForUserAsync(int userId)
        {
            var currencies = new[] { "RUB", "USD", "EUR", "TRL" };

            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            var sql = "INSERT INTO wallets (user_id, currency_code, balance) VALUES (@UserId, @CurrencyCode, 0)";

            var parameters = currencies.Select(currency => new { UserId = userId, CurrencyCode = currency });
            await connection.ExecuteAsync(sql, parameters);
        }

        public Task<Dictionary<string, decimal>> GetExchangeRatesAsync()
        {
            throw new NotImplementedException();
        }
    }

    // Модели данных
    public class WalletModel
    {
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public string CurrencyCode { get; set; }
        public decimal Balance { get; set; }
    }

    public class TransactionModel
    {
        public int TransactionId { get; set; }
        public int WalletId { get; set; }
        public decimal Amount { get; set; }
        public string CurrencyCode { get; set; }
        public string TransactionType { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}

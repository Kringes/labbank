﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace bb89.db
{
    public interface IDatabase
    {
        Task<int> GetUserIdAsync(string username, string password);
        Task CreateUserAsync(string username, string password);
        Task<List<WalletModel>> GetWalletsForUserAsync(int userId);
        Task UpdateWalletBalanceAsync(int walletId, decimal newBalance);
        Task<int> CreateWalletAsync(int userId, string currency, decimal initialBalance);
        Task<List<TransactionModel>> GetTransactionsForUserAsync(int userId);
        Task<Dictionary<string, decimal>> GetExchangeRatesAsync();
        Task<decimal> GetExchangeRateAsync(string fromCurrency, string toCurrency);
        Task CreateWalletsForUserAsync(int userId);
        
    }
}

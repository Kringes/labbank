﻿using System;
using Xunit;

namespace bb89.Tests
{
    public class ConversionResultTests
    {
        [Fact]
        public void Constructor_ShouldSetProperties_WhenInitializedSuccessfully()
        {
            // Arrange
            bool isSuccess = true;
            decimal convertedAmount = 100m;
            string? errorMessage = null;

            // Act
            var result = new ConversionResult(isSuccess, convertedAmount, errorMessage);

            // Assert
            Xunit.Assert.Equal(isSuccess, result.IsSuccess);
            Xunit.Assert.Equal(convertedAmount, result.ConvertedAmount);
            Xunit.Assert.Null(result.ErrorMessage);
        }

        [Fact]
        public void Constructor_ShouldSetErrorMessage_WhenConversionFails()
        {
            // Arrange
            bool isSuccess = false;
            decimal convertedAmount = 0m;
            string? errorMessage = "Insufficient funds";

            // Act
            var result = new ConversionResult(isSuccess, convertedAmount, errorMessage);

            // Assert
            Xunit.Assert.Equal(isSuccess, result.IsSuccess);
            Xunit.Assert.Equal(convertedAmount, result.ConvertedAmount);
            Xunit.Assert.Equal(errorMessage, result.ErrorMessage);
        }

        [Fact]
        public void Constructor_ShouldHandleNullErrorMessage_WhenSuccess()
        {
            // Arrange
            bool isSuccess = true;
            decimal convertedAmount = 100m;
            string? errorMessage = null;

            // Act
            var result = new ConversionResult(isSuccess, convertedAmount, errorMessage);

            // Assert
            Xunit.Assert.Equal(isSuccess, result.IsSuccess);
            Xunit.Assert.Equal(convertedAmount, result.ConvertedAmount);
            Xunit.Assert.Null(result.ErrorMessage);
        }

        [Fact]
        public void Constructor_ShouldHandleNonNullErrorMessage_WhenFailure()
        {
            // Arrange
            bool isSuccess = false;
            decimal convertedAmount = 0m;
            string? errorMessage = "Invalid currency";

            // Act
            var result = new ConversionResult(isSuccess, convertedAmount, errorMessage);

            // Assert
            Xunit.Assert.Equal(isSuccess, result.IsSuccess);
            Xunit.Assert.Equal(convertedAmount, result.ConvertedAmount);
            Xunit.Assert.Equal(errorMessage, result.ErrorMessage);
        }
    }
}

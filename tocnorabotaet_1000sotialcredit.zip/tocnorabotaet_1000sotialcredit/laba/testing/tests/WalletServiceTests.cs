﻿using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using bb89.db;
using bb89.services;
using Xunit;

namespace bb89.wall_service.Tests
{
    public class WalletServiceTests
    {
        [Fact]
        public async Task AddFundsAsync_ShouldUpdateWalletBalance()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();
            var userId = 1;
            var currencyCode = "RUB";
            var amount = 100m;
            var wallet = new WalletModel { WalletId = 1, UserId = userId, CurrencyCode = currencyCode, Balance = 500m };

            mockDatabase.Setup(db => db.GetWalletsForUserAsync(userId))
                        .ReturnsAsync(new List<WalletModel> { wallet });

            mockDatabase.Setup(db => db.UpdateWalletBalanceAsync(wallet.WalletId, wallet.Balance + amount))
                        .Returns(Task.CompletedTask);

            var walletService = new WalletService(mockDatabase.Object);

            // Act
            await walletService.AddFundsAsync(userId, currencyCode, amount);

            // Assert
            mockDatabase.Verify(db => db.UpdateWalletBalanceAsync(wallet.WalletId, 600m), Times.Once);
        }
        [Fact]
        public async Task CreateWalletsForUserAsync_ShouldCallCreateWalletsForUser()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();
            var userId = 1;

            mockDatabase.Setup(db => db.CreateWalletsForUserAsync(userId))
                        .Returns(Task.CompletedTask);

            var walletService = new WalletService(mockDatabase.Object);

            // Act
            await walletService.CreateWalletsForUserAsync(userId);

            // Assert
            mockDatabase.Verify(db => db.CreateWalletsForUserAsync(userId), Times.Once);
        }
        [Fact]
        public async Task AddFundsAsync_ShouldThrowException_WhenWalletNotFound()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();
            var userId = 1;
            var currencyCode = "USD";
            var amount = 100m;

            mockDatabase.Setup(db => db.GetWalletsForUserAsync(userId))
                        .ReturnsAsync(new List<WalletModel>()); // Пустой список кошельков

            var walletService = new WalletService(mockDatabase.Object);

            // Act & Assert
            await Xunit.Assert.ThrowsAsync<KeyNotFoundException>(() => walletService.AddFundsAsync(userId, currencyCode, amount));
        }

    }
}
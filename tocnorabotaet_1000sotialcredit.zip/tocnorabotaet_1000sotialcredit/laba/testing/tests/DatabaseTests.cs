﻿using Moq;
using Xunit;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace bb89.db.Tests
{
    public class DatabaseTests
    {
        [Fact]
        public async Task GetExchangeRatesAsync_ReturnsExchangeRates()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();
            var exchangeRates = new Dictionary<string, decimal>
            {
                { "USD", 1.0m },
                { "EUR", 0.85m }
            };

            mockDatabase.Setup(db => db.GetExchangeRatesAsync()).ReturnsAsync(exchangeRates);

            var database = mockDatabase.Object;

            // Act
            var result = await database.GetExchangeRatesAsync();

            // Assert
            Xunit.Assert.NotNull(result);
            Xunit.Assert.Equal(2, result.Count);
            Xunit.Assert.Equal(1.0m, result["USD"]);
            Xunit.Assert.Equal(0.85m, result["EUR"]);
        }

        [Fact]
        public async Task GetExchangeRateAsync_ThrowsException_WhenRateNotFound()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();

            mockDatabase.Setup(db => db.GetExchangeRateAsync(It.IsAny<string>(), It.IsAny<string>()))
                        .ThrowsAsync(new Exception("Exchange rate not found"));

            var database = mockDatabase.Object;

            // Act & Assert
            var exception = await Xunit.Assert.ThrowsAsync<Exception>(() => database.GetExchangeRateAsync("USD", "EUR"));
            Xunit.Assert.Equal("Exchange rate not found", exception.Message);
        }
    }
}

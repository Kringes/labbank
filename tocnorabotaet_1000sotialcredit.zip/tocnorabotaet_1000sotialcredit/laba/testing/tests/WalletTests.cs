﻿using System;
using System.Collections.Generic;
using Xunit;

namespace bb89.wallet.Tests
{
    public class WalletTests
    {
        [Fact]
        public void Deposit_ShouldIncreaseBalance_WhenAmountIsPositive()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });

            // Act
            wallet.Deposit("USD", 100m);

            // Assert
            Xunit.Assert.Equal(100m, wallet.GetBalance("USD"));
        }

        [Fact]
        public void Deposit_ShouldThrowArgumentException_WhenAmountIsNegative()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });

            // Act & Assert
            var exception = Xunit.Assert.Throws<ArgumentException>(() => wallet.Deposit("USD", -50m));
            Xunit.Assert.Equal("Сумма пополнения должна быть положительной", exception.Message);
        }

        [Fact]
        public void Withdraw_ShouldDecreaseBalance_WhenAmountIsValid()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });
            wallet.Deposit("USD", 100m);

            // Act
            var result = wallet.Withdraw("USD", 50m);

            // Assert
            Xunit.Assert.True(result);
            Xunit.Assert.Equal(50m, wallet.GetBalance("USD"));
        }

        [Fact]
        public void Withdraw_ShouldThrowInvalidOperationException_WhenInsufficientBalance()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });
            wallet.Deposit("USD", 50m);

            // Act & Assert
            var exception = Xunit.Assert.Throws<InvalidOperationException>(() => wallet.Withdraw("USD", 100m));
            Xunit.Assert.Equal("Insufficient balance.", exception.Message);
        }

        [Fact]
        public void Withdraw_ShouldThrowArgumentException_WhenCurrencyIsUnknown()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });

            // Act & Assert
            var exception = Xunit.Assert.Throws<ArgumentException>(() => wallet.Withdraw("GBP", 50m));
            Xunit.Assert.Equal("Unknown currency.", exception.Message);
        }

        [Fact]
        public void GetBalances_ShouldReturnAllBalances()
        {
            // Arrange
            var wallet = new Wallet(new[] { "USD", "EUR" });
            wallet.Deposit("USD", 100m);
            wallet.Deposit("EUR", 200m);

            // Act
            var balances = wallet.GetBalances();

            // Assert
            Xunit.Assert.Equal(100m, balances["USD"]);
            Xunit.Assert.Equal(200m, balances["EUR"]);
        }
    }
}

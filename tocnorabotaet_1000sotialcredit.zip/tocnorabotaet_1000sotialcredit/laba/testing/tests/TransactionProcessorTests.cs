﻿using bb89.convert;
using bb89.trans;
using bb89.wallet;
using bb89.trans_proc;
using Moq;
using Xunit;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace bb89.trans_proc.Tests
{
    public class TransactionProcessorTests
    {
        [Fact]
        public async Task HandleDepositAsync_AddsTransactionAndUpdatesWallet()
        {
            // Arrange
            var walletMock = new Mock<IWallet>();
            var converterMock = new Mock<ICurrencyConverter>();
            var historyMock = new Mock<ITransactionHistory>();

            var processor = new TransactionProcessor(walletMock.Object, converterMock.Object, historyMock.Object);
            var currency = "USD";
            var amount = 100m;

            // Act
            await processor.HandleDepositAsync(currency, amount);

            // Assert
            walletMock.Verify(w => w.Deposit(currency, amount), Times.Once);
            historyMock.Verify(h => h.AddTransaction(It.Is<string>(s => s.Contains($"Пополнение {amount} {currency}"))), Times.Once);
        }

        [Fact]
        public async Task HandleConversionAsync_WithdrawsFromWalletAndConvertsCurrency()
        {
            // Arrange
            var walletMock = new Mock<IWallet>();
            var converterMock = new Mock<ICurrencyConverter>();
            var historyMock = new Mock<ITransactionHistory>();

            walletMock.Setup(w => w.Withdraw("USD", 50m)).Returns(true);
            converterMock.Setup(c => c.ConvertAsync(50m, "USD", "EUR")).ReturnsAsync(45m);

            var processor = new TransactionProcessor(walletMock.Object, converterMock.Object, historyMock.Object);

            // Act
            await processor.HandleConversionAsync("USD", "EUR", 50m);

            // Assert
            walletMock.Verify(w => w.Withdraw("USD", 50m), Times.Once);
            walletMock.Verify(w => w.Deposit("EUR", 45m), Times.Once);
            historyMock.Verify(h => h.AddTransaction(It.Is<string>(s => s.Contains("Конвертация 50 USD в 45 EUR"))), Times.Once);
        }

        [Fact]
        public async Task HandleConversionAsync_InsufficientFunds_PrintsMessage()
        {
            // Arrange
            var walletMock = new Mock<IWallet>();
            var converterMock = new Mock<ICurrencyConverter>();
            var historyMock = new Mock<ITransactionHistory>();

            walletMock.Setup(w => w.Withdraw("USD", 50m)).Returns(false);

            var processor = new TransactionProcessor(walletMock.Object, converterMock.Object, historyMock.Object);

            // Act
            await processor.HandleConversionAsync("USD", "EUR", 50m);

            // Assert
            walletMock.Verify(w => w.Withdraw("USD", 50m), Times.Once);
            converterMock.Verify(c => c.ConvertAsync(It.IsAny<decimal>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            walletMock.Verify(w => w.Deposit(It.IsAny<string>(), It.IsAny<decimal>()), Times.Never);
            historyMock.Verify(h => h.AddTransaction(It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public void DisplayTransactionHistory_PrintsAllTransactions()
        {
            // Arrange
            var walletMock = new Mock<IWallet>();
            var converterMock = new Mock<ICurrencyConverter>();
            var historyMock = new Mock<ITransactionHistory>();

            historyMock.Setup(h => h.GetTransactions()).Returns(new List<string> { "Transaction 1", "Transaction 2" });

            var processor = new TransactionProcessor(walletMock.Object, converterMock.Object, historyMock.Object);

            // Act
            processor.DisplayTransactionHistory();

            // Assert
            historyMock.Verify(h => h.GetTransactions(), Times.Once);
        }
       
    }
}

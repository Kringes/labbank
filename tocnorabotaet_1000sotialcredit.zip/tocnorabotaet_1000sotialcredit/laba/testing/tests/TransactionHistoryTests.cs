﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Xunit;

namespace bb89.trans.Tests
{
    public class TransactionHistoryTests
    {
        private readonly string testFilePath = "test_transactions.json";

        [Fact]
        public async Task InitializeAsync_LoadsHistoryFromFile()
        {
            // Arrange
            var existingTransactions = new List<string> { "Transaction 1", "Transaction 2" };
            File.WriteAllText(testFilePath, JsonConvert.SerializeObject(existingTransactions));

            var transactionHistory = new TransactionHistory(testFilePath);

            // Act
            await transactionHistory.InitializeAsync();
            var loadedTransactions = transactionHistory.GetTransactions();

            // Assert
            Xunit.Assert.Equal(existingTransactions.Count, loadedTransactions.Count);
            Xunit.Assert.Contains("Transaction 1", loadedTransactions);
            Xunit.Assert.Contains("Transaction 2", loadedTransactions);

            // Cleanup
            File.Delete(testFilePath);
        }

        [Fact]
        public async Task AddTransaction_AddsTransactionToList()
        {
            // Arrange
            var transactionHistory = new TransactionHistory(testFilePath);
            await transactionHistory.InitializeAsync();

            // Act
            transactionHistory.AddTransaction("New Transaction");
            var transactions = transactionHistory.GetTransactions();

            // Assert
            Xunit.Assert.Single(transactions);
            Xunit.Assert.Contains("New Transaction", transactions);

            // Cleanup
            File.Delete(testFilePath);
        }

        [Fact]
        public async Task SaveHistoryAsync_SavesTransactionsToFile()
        {
            // Arrange
            var transactionHistory = new TransactionHistory(testFilePath);
            await transactionHistory.InitializeAsync();

            transactionHistory.AddTransaction("Saved Transaction");

            // Act
            await transactionHistory.SaveHistoryAsync();

            // Assert
            var savedJson = File.ReadAllText(testFilePath);
            var savedTransactions = JsonConvert.DeserializeObject<List<string>>(savedJson);

            Xunit.Assert.NotNull(savedTransactions);
            Xunit.Assert.Single(savedTransactions);
            Xunit.Assert.Contains("Saved Transaction", savedTransactions);

            // Cleanup
            File.Delete(testFilePath);
        }

        [Fact]
        public async Task InitializeAsync_CreatesNewFileIfNotExists()
        {
            // Arrange
            if (File.Exists(testFilePath))
                File.Delete(testFilePath);

            var transactionHistory = new TransactionHistory(testFilePath);

            // Act
            await transactionHistory.InitializeAsync();
            var transactions = transactionHistory.GetTransactions();

            // Assert
            Xunit.Assert.Empty(transactions);
            Xunit.Assert.True(File.Exists(testFilePath)); // Проверяем, что файл был создан

            // Cleanup
            File.Delete(testFilePath);
        }
    }
}

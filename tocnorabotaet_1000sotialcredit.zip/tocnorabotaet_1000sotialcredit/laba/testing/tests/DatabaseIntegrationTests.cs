﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Threading.Tasks;
using Dapper;
using Xunit;
using bb89.wallet;

namespace bb89.db.Tests
{
    public class DatabaseIntegrationTests
    {
        private readonly string _connectionString;

        public DatabaseIntegrationTests()
        {
            // Путь к вашей базе данных
            _connectionString = "Data Source=path_to_your_database_file.db;Version=3;";
        }

        private async Task CreateTablesIfNotExistAsync()
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            // Проверяем, существуют ли таблицы, и создаем их, если их нет
            await connection.ExecuteAsync(@"
                CREATE TABLE IF NOT EXISTS exchange_rates (
                    currency_code TEXT PRIMARY KEY,
                    rate DECIMAL
                );

                CREATE TABLE IF NOT EXISTS wallets (
                    wallet_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    currency_code TEXT,
                    balance DECIMAL
                );
            ");
        }

        private async Task InsertTestDataAsync()
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            // Вставляем тестовые данные в таблицы
            await connection.ExecuteAsync(@"INSERT OR IGNORE INTO exchange_rates (currency_code, rate) VALUES 
                                        ('USD', 1.0), 
                                        ('EUR', 0.85)");

            // Удаляем все кошельки для пользователя перед вставкой
            await connection.ExecuteAsync(@"DELETE FROM wallets WHERE user_id = 1");

            // Вставляем тестовые данные для кошельков
            await connection.ExecuteAsync(@"INSERT INTO wallets (user_id, currency_code, balance) 
                                        VALUES (1, 'USD', 100.0), 
                                               (1, 'EUR', 50.0)");
        }


        [Fact]
        public async Task GetExchangeRatesAsync_ReturnsExchangeRates_FromDatabase()
        {
            // Arrange
            await CreateTablesIfNotExistAsync();
            await InsertTestDataAsync();
            var db = new Database(_connectionString);

            // Act
            var exchangeRates = await db.GetExchangeRatesAsync();

            // Assert
            Xunit.Assert.NotNull(exchangeRates);
            Xunit.Assert.Contains("USD", exchangeRates);
            Xunit.Assert.Equal(1.0m, exchangeRates["USD"]);
            Xunit.Assert.Contains("EUR", exchangeRates);
            Xunit.Assert.Equal(0.85m, exchangeRates["EUR"]);
        }

       
        


    }
}

﻿using System;
using System.Data.SQLite;
using Dapper;
using NUnit.Framework;
using bb89.menu;

namespace bb89.menumain.Tests
{
    [TestFixture]
    public class ShowMainMenuTests
    {
        private string _testDbPath;
        private string _connectionString;

        [SetUp]
        public void Setup()
        {
            // Создаем временную тестовую базу
            _testDbPath = "TestDatabase.db";
            _connectionString = $"Data Source={_testDbPath}";
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                var createUsersTable = @"
                    CREATE TABLE users (
                        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT NOT NULL,
                        password TEXT NOT NULL
                    )";
                var createWalletsTable = @"
                    CREATE TABLE wallets (
                        wallet_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        currency_code TEXT NOT NULL,
                        balance REAL NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users(user_id)
                    )";
                connection.Execute(createUsersTable);
                connection.Execute(createWalletsTable);
            }
        }

        [TearDown]
        public void TearDown()
        {
            if (System.IO.File.Exists(_testDbPath))
            {
                System.IO.File.Delete(_testDbPath);
            }
        }
        public void Dispose()
        {
            // Удаляем тестовую базу данных
            var dbFile = new System.IO.FileInfo(_connectionString.Split('=')[1].Trim(';'));
            if (dbFile.Exists)
            {
                dbFile.Delete();
            }
        }

        [Test]
        public void CreateUser_ShouldAddUserAndWallets()
        {
            // Arrange
            var menu = new ShowMainMenu(_connectionString);

            // Act
            menu.CreateUser("test_user", "test_password");

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Assert: Проверяем, что пользователь создан
                var userCount = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM users WHERE username = 'test_user'");
                Assert.AreEqual(1, userCount);

                // Assert: Проверяем, что созданы 4 кошелька
                var walletCount = connection.ExecuteScalar<int>("SELECT COUNT(*) FROM wallets WHERE user_id = (SELECT user_id FROM users WHERE username = 'test_user')");
                Assert.AreEqual(4, walletCount);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using bb89.convert;
using bb89.db;
using Moq;
using Xunit;

namespace bb89.curconvert.Tests
{
    public class CurrencyConverterTests
    {
        [Fact]
        public async Task ConvertAsync_ValidCurrencies_ReturnsConvertedAmount()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();  // Мокируем интерфейс
            var exchangeRates = new Dictionary<string, decimal>
        {
            { "USD", 1.0m },
            { "EUR", 0.85m }
        };

            // Мокаем метод GetExchangeRatesAsync интерфейса
            mockDatabase.Setup(db => db.GetExchangeRatesAsync()).ReturnsAsync(exchangeRates);

            // Теперь передаем мок интерфейса в конструктор CurrencyConverter
            var converter = new CurrencyConverter(mockDatabase.Object);

            // Act
            var result = await converter.ConvertAsync(100m, "USD", "EUR");

            // Assert
            Xunit.Assert.Equal(85.0m, result);  // 100 * (0.85 / 1)
        }

        [Fact]
        public async Task ConvertAsync_InvalidCurrency_ThrowsInvalidOperationException()
        {
            // Arrange
            var mockDatabase = new Mock<IDatabase>();  // Мокируем интерфейс
            var exchangeRates = new Dictionary<string, decimal>
        {
            { "USD", 1.0m }  // EUR отсутствует
        };

            // Мокаем метод GetExchangeRatesAsync интерфейса
            mockDatabase.Setup(db => db.GetExchangeRatesAsync()).ReturnsAsync(exchangeRates);

            // Теперь передаем мок интерфейса в конструктор CurrencyConverter
            var converter = new CurrencyConverter(mockDatabase.Object);

            // Act & Assert
            var exception = await Xunit.Assert.ThrowsAsync<InvalidOperationException>(() => converter.ConvertAsync(100m, "USD", "EUR"));
            Xunit.Assert.Equal("Курс валюты не найден.", exception.Message);
        }
    }


}

﻿using Moq;
using System.Data.SQLite;



namespace testdb
{
    [TestFixture]
    public class ShowMainMenuTests
    {
        private Mock<SQLiteConnection> _mockConnection;
        private ShowMainMenu _showMainMenu;

        [SetUp]
        public void Setup()
        {
            // Создаем мок объекта для SQLite соединения
            _mockConnection = new Mock<SQLiteConnection>("Data Source=Test.db");
            _showMainMenu = new ShowMainMenu();
        }

        [Test]
        public void CreateUser_CreatesUserInDatabase()
        {
            // Мокаем взаимодействие с базой данных
            _mockConnection.Setup(m => m.Open()).Verifiable();

            string username = "TestUser";
            string password = "TestPassword";

            // Запуск метода CreateUser
            _showMainMenu.CreateUser(username, password);

            // Проверяем, что запрос на добавление пользователя был выполнен
            _mockConnection.Verify(m => m.ExecuteNonQuery(It.IsAny<string>(), It.IsAny<object[]>()), Times.Once);
        }

        [Test]
        public void LoginUser_WithCorrectCredentials_LogsUserIn()
        {
            // Настройка моков для правильного входа
            var mockDb = new Mock<SQLiteConnection>("Data Source=Test.db");
            mockDb.Setup(db => db.ExecuteScalar(It.IsAny<string>(), It.IsAny<object[]>()))
                  .Returns(1); // Возвращаем id пользователя

            _showMainMenu.LoginUser("TestUser", "TestPassword");

            // Проверяем, что метод логина вызвался корректно
            mockDb.Verify(m => m.ExecuteScalar(It.IsAny<string>(), It.IsAny<object[]>()), Times.Once);
        }
    }
}
